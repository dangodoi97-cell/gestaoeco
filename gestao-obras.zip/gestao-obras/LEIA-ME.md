# Gestão de Obras — Guia de Configuração

Este sistema tem 3 áreas:
- **Login** (`index.html`) — tela inicial, onde admin e cliente entram
- **Admin** (`admin/index.html`) — seu painel completo
- **Cliente** (`cliente/index.html`) — painel do seu patrão/cliente

---

## PASSO 1 — Configurar as regras do Firestore

1. No Firebase, vá em **Firestore Database** → aba **Regras**
2. Apague tudo que estiver lá e cole o conteúdo do arquivo `firestore.rules` (está junto dos outros arquivos)
3. Clique em **Publicar**

## PASSO 2 — Configurar as regras do Storage

1. No Firebase, vá em **Storage** → se ainda não tiver ativado, clique em **Começar** → modo de teste → Avançar → Concluir (escolha a mesma região do Firestore)
2. Vá na aba **Regras**
3. Apague tudo e cole o conteúdo do arquivo `storage.rules`
4. Clique em **Publicar**

## PASSO 3 — Criar o seu primeiro login de ADMIN

Como o cadastro normal do app só cria contas de **cliente**, o primeiro admin precisa ser criado manualmente uma única vez:

1. No Firebase, vá em **Authentication** → aba **Users** → **Add user**
2. Coloque seu e-mail e uma senha → **Add user**
3. Copie o **UID** gerado (aparece na listagem de usuários)
4. Vá em **Firestore Database** → **Iniciar coleção**
5. ID da coleção: `usuarios`
6. ID do documento: cole o **UID** que você copiou
7. Adicione estes campos:
   - `nome` (string) → seu nome
   - `email` (string) → seu e-mail
   - `tipo` (string) → `admin`
   - `status` (string) → `aprovado`
8. Clique em **Salvar**

Pronto! Agora você consegue entrar em `index.html` com esse e-mail/senha e cair direto no painel admin. Pelo próprio painel, em **Mais → Administradores**, você pode criar outros admins no futuro sem repetir esse processo manual.

## PASSO 4 — Subir os arquivos no Netlify

1. Acesse **netlify.com** → crie conta gratuita
2. Arraste a **pasta inteira** do projeto (não só um arquivo) para a área de upload
3. Em segundos você recebe um link tipo `seusite.netlify.app`

## PASSO 5 — Instalar como app no celular

No Android (Chrome): abra o link → menu (3 pontinhos) → "Adicionar à tela inicial"
No iPhone (Safari): abra o link → ícone de compartilhar → "Adicionar à Tela de Início"

---

## Como funciona o fluxo

**Você (admin):**
- Entra com seu e-mail/senha em `index.html`
- Cadastra parceiros (pedreiros), obras, etapas, encargos, tabela de preços/repasse
- Aprova ou rejeita clientes que se cadastraram
- Vê o andamento de tudo, mas a aprovação final do serviço é feita pelo cliente

**Seu cliente:**
- Cria a própria conta em `index.html` (aba "Criar conta")
- Fica com status "pendente" até você aprovar em **Mais → Clientes**
- Depois de aprovado, vê apenas as obras vinculadas a ele
- Pode revisar, aprovar/rejeitar cada etapa concluída, marcar como Pago ou A Pagar, e deixar anotações

**Vincular obra a um cliente:**
Ao criar a obra no admin, selecione o cliente no campo "Cliente responsável". Só clientes já aprovados aparecem na lista.

---

## Estrutura de arquivos

```
/
├── index.html          ← tela de login
├── pendente.html        ← tela de "aguardando aprovação"
├── manifest.json
├── firestore.rules      ← colar no Firebase
├── storage.rules        ← colar no Firebase
├── css/
│   └── style.css
├── js/
│   ├── firebase-config.js
│   ├── auth.js
│   └── data.js
├── admin/
│   ├── index.html
│   └── app.js
└── cliente/
    ├── index.html
    └── app.js
```

## Ajustes futuros

Qualquer mudança que precisar depois, é só trazer os arquivos de volta e pedir o ajuste — a estrutura modular faz com que eu só precise tocar no arquivo certo, sem precisar reescrever tudo de novo.
