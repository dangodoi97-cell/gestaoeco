// ============================================
// APP CLIENTE
// ============================================
import { observarAuth, logout } from '../js/auth.js';
import {
  escutarObras, escutarEtapas, escutarTodasEtapas,
  atualizarEtapa, escutarPrecos,
  hoje, diasDiff
} from '../js/data.js';

let usuarioAtual = null;

observarAuth(async (user, perfil) => {
  if (!user) { window.location.href = '../index.html'; return; }
  if (!perfil || perfil.tipo !== 'cliente') { window.location.href = '../index.html'; return; }
  if (perfil.status !== 'aprovado') { window.location.href = '../pendente.html'; return; }
  usuarioAtual = { uid: user.uid, ...perfil };
  document.getElementById('loading').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  iniciarApp();
});

window.sairConta = async () => { await logout(); window.location.href = '../index.html'; };

let db_obras = [];
let db_precos = [];
let obraAtiva = null;
let unsubEtapasAtivas = null;
let unsubTodasEtapas = null;
let revisarObraId = null, revisarEtapaId = null;
let pagamentoSelecionado = null;

function iniciarApp() {
  escutarObras(obras => {
    db_obras = obras;
    renderObras();
    if (document.getElementById('page-obra-detalhe').classList.contains('active') && obraAtiva) {
      const atualizada = obras.find(o => o.id === obraAtiva.id);
      if (atualizada) { obraAtiva = atualizada; renderDetalheObra(); }
    }
    if (unsubTodasEtapas) unsubTodasEtapas();
    unsubTodasEtapas = escutarTodasEtapas(obras, todas => {
      window._todasEtapas = todas;
      renderHistorico();
      renderAprovacao();
      updateBadge();
    });
  }, usuarioAtual.uid);
  escutarPrecos(p => { db_precos = p; renderPrecos(); });
}

function toast(m) { const t = document.getElementById('toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2400); }
window.bgClose = (e, id) => { if (e.target === document.getElementById(id)) document.getElementById(id).classList.remove('show'); };
window.openLightbox = (src, label) => {
  document.getElementById('lightbox-img').src = src;
  document.getElementById('lightbox-label').textContent = label;
  document.getElementById('lightbox').classList.add('show');
  document.body.style.overflow = 'hidden';
};
window.closeLightbox = () => { document.getElementById('lightbox').classList.remove('show'); document.body.style.overflow = ''; };

function fotosHTML(antes, depois, extras) {
  let html = '';
  if (antes || depois) {
    const item = (src, label) => src
      ? `<div><div class="foto-wrap" onclick="openLightbox('${src}','${label}')"><img src="${src}" alt="${label}"></div><div class="foto-lbl">${label}</div></div>`
      : `<div><div class="foto-sem">Sem foto</div><div class="foto-lbl">${label}</div></div>`;
    html += `<div class="fotos-grid">${item(antes, 'Antes')}${item(depois, 'Depois')}</div>`;
  }
  if (extras && extras.length) {
    html += `<div class="fotos-grid" style="margin-top:6px">` + extras.map(f =>
      `<div><div class="foto-wrap" onclick="openLightbox('${f.url}','${f.legenda || 'Foto extra'}')"><img src="${f.url}" alt=""></div><div class="foto-lbl">${f.legenda || 'Execução'}</div></div>`
    ).join('') + `</div>`;
  }
  return html;
}

const TITULOS = { obras: 'Minhas obras', historico: 'Histórico', aprovacao: 'Aprovação', precos: 'Tabela de preços' };
window.goPage = function (p) {
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + p).classList.add('active');
  const navEl = document.getElementById('nav-' + p);
  if (navEl) navEl.classList.add('active');
  if (TITULOS[p]) document.getElementById('topbar-content').innerHTML = `<h1>${TITULOS[p]}</h1>`;
  updateBadge();
};

function updateBadge() {
  const todas = window._todasEtapas || [];
  const n = todas.filter(e => e.status === 'concluido' && e.aprovacao === 'pendente').length;
  document.getElementById('dot-aprov').classList.toggle('show', n > 0);
}

// ---------- OBRAS ----------
function renderObras() {
  const el = document.getElementById('lista-obras');
  if (!db_obras.length) { el.innerHTML = `<div class="empty"><i class="ti ti-building-off"></i><p>Nenhuma obra vinculada ao seu cadastro ainda.</p></div>`; return; }
  el.innerHTML = db_obras.map(o => {
    const atrasada = o.status === 'andamento' && o.fim && o.fim < hoje();
    return `<div class="list-card" onclick="abrirObra('${o.id}')">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
        <div style="flex:1;min-width:0">
          <div style="font-size:16px;font-weight:600">${o.nome}</div>
          ${o.local ? `<div style="font-size:12px;color:var(--text-muted)">${o.local}</div>` : ''}
        </div>
        <span class="badge ${o.status === 'andamento' ? 'badge-and' : 'badge-done'}">${o.status === 'andamento' ? 'Em andamento' : 'Concluída'}</span>
      </div>
      ${atrasada ? `<div class="alert-box alert-danger"><i class="ti ti-alert-triangle"></i>Prazo vencido</div>` : ''}
    </div>`;
  }).join('');
}

window.abrirObra = function (id) {
  obraAtiva = db_obras.find(o => o.id === id);
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('page-obra-detalhe').classList.add('active');
  document.getElementById('topbar-content').innerHTML = `<h1 style="font-size:15px">${obraAtiva.nome}</h1>`;
  if (unsubEtapasAtivas) unsubEtapasAtivas();
  unsubEtapasAtivas = escutarEtapas(id, etapas => { obraAtiva._etapas = etapas; renderDetalheObra(); });
};

function renderDetalheObra() {
  if (!obraAtiva) return;
  const o = obraAtiva;
  const etapas = o._etapas || [];
  const done = etapas.filter(e => e.status === 'concluido').length;
  const pct = etapas.length ? Math.round(done / etapas.length * 100) : 0;
  const gasto = etapas.reduce((s, e) => s + parseFloat((e.val || '0').replace(',', '.')), 0);
  const atrasada = o.status === 'andamento' && o.fim && o.fim < hoje();
  document.getElementById('obra-detalhe-header').innerHTML = `
    <div class="card">
      <span class="badge ${o.status === 'andamento' ? 'badge-and' : 'badge-done'}">${o.status === 'andamento' ? 'Em andamento' : 'Concluída'}</span>
      ${atrasada ? `<div class="alert-box alert-danger"><i class="ti ti-alert-triangle"></i>Prazo vencido — previsão: ${o.fim}</div>` : ''}
      ${o.desc ? `<p style="font-size:13px;color:var(--text-secondary);margin-top:8px">${o.desc}</p>` : ''}
      <div class="g3" style="margin-top:10px">
        <div class="stat"><span class="stat-val">${etapas.length}</span><span class="stat-lbl">Etapas</span></div>
        <div class="stat"><span class="stat-val">${pct}%</span><span class="stat-lbl">Progresso</span></div>
        <div class="stat"><span class="stat-val" style="font-size:14px">R$ ${gasto.toFixed(2).replace('.', ',')}</span><span class="stat-lbl">Total</span></div>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
    </div>`;
  renderEtapas();
}

function renderEtapas() {
  const etapas = obraAtiva._etapas || [];
  const el = document.getElementById('obra-etapas');
  if (!etapas.length) { el.innerHTML = `<div class="empty"><i class="ti ti-clipboard"></i><p>Nenhuma etapa registrada ainda.</p></div>`; return; }
  const hoje_ = hoje();
  el.innerHTML = etapas.map(e => {
    const atrasada = e.status === 'execucao' && e.prazo && e.prazo < hoje_;
    const dr = e.prazo ? diasDiff(hoje_, e.prazo) : null;
    let tempoReal = '';
    if (e.status === 'concluido' && e.inicio && e.dataConc) { const d = diasDiff(e.inicio, e.dataConc); tempoReal = ` · ${d} dia${d !== 1 ? 's' : ''} real`; }
    const pagamentoBadge = e.status === 'concluido' && e.aprovacao === 'aprovado' ? `<span class="badge ${e.pagamento === 'pago' ? 'badge-pago' : 'badge-apagar'}">${e.pagamento === 'pago' ? 'Pago' : 'A pagar'}</span>` : '';
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div style="font-size:15px;font-weight:600">${e.tipo}</div>
          ${obraAtiva.mostrarPedreiro !== false ? `<div style="font-size:12px;color:var(--text-muted)">${e.parceiroNome || ''}</div>` : ''}
        </div>
        <div style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end">
          <span class="badge ${e.status === 'execucao' ? 'badge-exec' : e.aprovacao === 'aprovado' ? 'badge-aprov' : e.aprovacao === 'rejeitado' ? 'badge-rej' : 'badge-pend'}">${e.status === 'execucao' ? 'Em execução' : e.aprovacao === 'aprovado' ? 'Aprovado' : e.aprovacao === 'rejeitado' ? 'Rejeitado' : 'Aguardando aprovação'}</span>
          ${pagamentoBadge}
        </div>
      </div>
      <div class="divider"></div>
      <div class="g2">
        <div><div style="font-size:11px;color:var(--text-muted)">Valor</div><div style="font-size:13px;font-weight:600;color:var(--text-success)">${e.val ? 'R$ ' + e.val : '—'}</div></div>
        ${e.metros ? `<div><div style="font-size:11px;color:var(--text-muted)">Quantidade</div><div style="font-size:13px">${e.metros} m²</div></div>` : ''}
        <div><div style="font-size:11px;color:var(--text-muted)">Início</div><div style="font-size:13px">${e.inicio || '—'}</div></div>
        ${e.status === 'execucao' ? `<div><div style="font-size:11px;color:var(--text-muted)">Previsão</div><div style="font-size:13px${atrasada ? ';color:var(--text-danger)' : ''}">${e.prazo || '—'}</div></div>` : `<div><div style="font-size:11px;color:var(--text-muted)">Tempo real</div><div style="font-size:13px">${tempoReal.replace(' · ', '') || '—'}</div></div>`}
      </div>
      ${atrasada ? `<div class="alert-box alert-danger" style="margin-top:8px"><i class="ti ti-alert-triangle"></i>Prazo vencido</div>` : ''}
      ${e.nota ? `<div class="alert-box alert-warning" style="margin-top:8px"><i class="ti ti-note"></i>${e.nota}</div>` : ''}
      ${fotosHTML(e.fotoAntes, e.fotoDepois, e.fotosExtras)}
      ${e.status === 'concluido' && e.aprovacao === 'pendente' ? `<button class="btn-main" style="margin-top:12px" onclick="abrirRevisar('${obraAtiva.id}','${e.id}')">Revisar e aprovar</button>` : ''}
    </div>`;
  }).join('');
}

// ---------- HISTÓRICO (global) ----------
function renderHistorico() {
  const el = document.getElementById('lista-historico');
  const rows = (window._todasEtapas || []).filter(e => e.status === 'concluido');
  if (!rows.length) { el.innerHTML = `<div class="empty"><i class="ti ti-history"></i><p>Nenhum serviço concluído ainda.</p></div>`; return; }
  el.innerHTML = rows.map(e => {
    const pagamentoBadge = `<span class="badge ${e.pagamento === 'pago' ? 'badge-pago' : 'badge-apagar'}">${e.pagamento === 'pago' ? 'Pago' : 'A pagar'}</span>`;
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div><div style="font-size:15px;font-weight:600">${e.tipo}</div><div style="font-size:12px;color:var(--text-muted)">${e.obraNome}</div></div>
        <div style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end">
          <span class="badge ${e.aprovacao === 'aprovado' ? 'badge-aprov' : e.aprovacao === 'rejeitado' ? 'badge-rej' : 'badge-pend'}">${e.aprovacao === 'aprovado' ? 'Aprovado' : e.aprovacao === 'rejeitado' ? 'Rejeitado' : 'Pendente'}</span>
          ${e.aprovacao === 'aprovado' ? pagamentoBadge : ''}
        </div>
      </div>
      <div class="divider"></div>
      <div class="g2">
        <div><div style="font-size:11px;color:var(--text-muted)">Valor</div><div style="font-size:13px;font-weight:600;color:var(--text-success)">${e.val ? 'R$ ' + e.val : '—'}</div></div>
        <div><div style="font-size:11px;color:var(--text-muted)">Concluído em</div><div style="font-size:13px">${e.dataConc || '—'}</div></div>
      </div>
      ${e.nota ? `<div class="alert-box alert-warning" style="margin-top:8px"><i class="ti ti-note"></i>${e.nota}</div>` : ''}
      ${fotosHTML(e.fotoAntes, e.fotoDepois, e.fotosExtras)}
    </div>`;
  }).join('');
}

// ---------- APROVAÇÃO (global) ----------
function renderAprovacao() {
  const el = document.getElementById('lista-aprovacao');
  const rows = (window._todasEtapas || []).filter(e => e.status === 'concluido' && e.aprovacao === 'pendente');
  if (!rows.length) { el.innerHTML = `<div class="empty"><i class="ti ti-circle-check"></i><p>Nenhum serviço aguardando aprovação.</p></div>`; return; }
  el.innerHTML = rows.map(e => `<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div><div style="font-size:15px;font-weight:600">${e.tipo}</div><div style="font-size:12px;color:var(--text-muted)">${e.obraNome}</div></div>
      <span class="badge badge-pend">Pendente</span>
    </div>
    <div class="divider"></div>
    <div class="g2" style="margin-bottom:10px">
      <div><div style="font-size:11px;color:var(--text-muted)">Valor</div><div style="font-size:13px;font-weight:600;color:var(--text-success)">${e.val ? 'R$ ' + e.val : '—'}</div></div>
      <div><div style="font-size:11px;color:var(--text-muted)">Concluído em</div><div style="font-size:13px">${e.dataConc || '—'}</div></div>
    </div>
    ${fotosHTML(e.fotoAntes, e.fotoDepois, e.fotosExtras)}
    <button class="btn-main" style="margin-top:12px" onclick="abrirRevisar('${e.obraId}','${e.id}')">Revisar e aprovar</button>
  </div>`).join('');
}

// ---------- REVISAR / APROVAR / PAGAMENTO ----------
window.abrirRevisar = function (obraId, etapaId) {
  revisarObraId = obraId; revisarEtapaId = etapaId;
  pagamentoSelecionado = null;
  const etapa = (window._todasEtapas || []).find(e => e.id === etapaId) || (obraAtiva._etapas || []).find(e => e.id === etapaId);
  document.getElementById('revisar-conteudo').innerHTML = `
    <div class="card" style="margin-bottom:0">
      <div style="font-size:15px;font-weight:600">${etapa.tipo}</div>
      <div style="font-size:13px;color:var(--text-success);font-weight:600;margin-top:4px">${etapa.val ? 'R$ ' + etapa.val : '—'}</div>
      ${fotosHTML(etapa.fotoAntes, etapa.fotoDepois, etapa.fotosExtras)}
    </div>`;
  document.getElementById('revisar-nota').value = etapa.nota || '';
  resetBotoesPagamento();
  document.getElementById('modal-revisar').classList.add('show');
};

function resetBotoesPagamento() {
  document.getElementById('btn-marcar-pago').classList.remove('btn-success');
  document.getElementById('btn-marcar-apagar').classList.remove('btn-danger');
}
window.marcarPagamento = function (status) {
  pagamentoSelecionado = status;
  resetBotoesPagamento();
  if (status === 'pago') document.getElementById('btn-marcar-pago').classList.add('btn-success');
  else document.getElementById('btn-marcar-apagar').classList.add('btn-danger');
};

window.aprovarServico = async function () {
  const nota = document.getElementById('revisar-nota').value.trim();
  await atualizarEtapa(revisarObraId, revisarEtapaId, { aprovacao: 'aprovado', nota, pagamento: pagamentoSelecionado || 'a_pagar' });
  document.getElementById('modal-revisar').classList.remove('show');
  toast('Serviço aprovado');
};
window.rejeitarServico = async function () {
  const nota = document.getElementById('revisar-nota').value.trim();
  if (!nota) { toast('Descreva o motivo da rejeição na anotação'); return; }
  await atualizarEtapa(revisarObraId, revisarEtapaId, { aprovacao: 'rejeitado', nota });
  document.getElementById('modal-revisar').classList.remove('show');
  toast('Serviço rejeitado');
};

// ---------- PREÇOS ----------
function renderPrecos() {
  const el = document.getElementById('lista-precos');
  if (!db_precos.length) { el.innerHTML = `<div class="empty"><i class="ti ti-receipt-off"></i><p>Nenhum preço cadastrado.</p></div>`; return; }
  el.innerHTML = db_precos.map(p => `<div class="price-row"><span class="price-name">${p.nome}</span><span class="price-val">R$ ${p.val}/m²</span></div>`).join('');
}
