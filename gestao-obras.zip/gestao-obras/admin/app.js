// ============================================
// APP ADMIN
// ============================================
import { auth, db, doc, getDoc } from '../js/firebase-config.js';
import { observarAuth, logout, cadastrarAdmin, mensagemErroFirebase } from '../js/auth.js';
import {
  criarObra, atualizarObra, escutarObras, buscarObra,
  criarEtapa, atualizarEtapa, escutarEtapas, escutarTodasEtapas,
  criarEncargo, escutarEncargos, excluirEncargo,
  escutarPrecos, criarPreco, atualizarPreco, excluirPreco,
  escutarRepasses, criarRepasse, atualizarRepasse, excluirRepasse,
  escutarParceiros, criarParceiro, atualizarParceiro, excluirParceiro,
  escutarClientes, aprovarCliente, rejeitarCliente,
  escutarAdmins,
  uploadFoto, fileParaBase64,
  hoje, diasDiff
} from '../js/data.js';

// ---------- AUTENTICAÇÃO / GATEKEEPER ----------
let usuarioAtual = null;

observarAuth(async (user, perfil) => {
  if (!user) { window.location.href = '../index.html'; return; }
  if (!perfil || perfil.tipo !== 'admin') { window.location.href = '../index.html'; return; }
  usuarioAtual = { uid: user.uid, ...perfil };
  document.getElementById('loading').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  iniciarApp();
});

window.sairConta = async () => { await logout(); window.location.href = '../index.html'; };

// ---------- ESTADO GLOBAL ----------
let db_obras = [];
let db_precos = [];
let db_repasses = [];
let db_parceiros = [];
let db_clientes = [];
let db_admins = [];
let obraAtiva = null;
let etapaConclId = null;
let editPrecoId = null;
let editRepasseId = null;
let editParceiroId = null;
let parceiroDetalheId = null;
let etFotos = {};
let concFoto = null;
let encFoto = null;
let extraFoto = null;
let unsubEtapasAtivas = null;
let unsubTodasEtapas = null;
let unsubEncargos = null;

function iniciarApp() {
  escutarObras(obras => {
    db_obras = obras;
    renderObras();
    if (document.getElementById('page-obra-detalhe').classList.contains('active') && obraAtiva) {
      const atualizada = obras.find(o => o.id === obraAtiva.id);
      if (atualizada) { obraAtiva = atualizada; renderDetalheObra(); }
    }
    // Atualiza listeners agregados para execução/aprovação
    if (unsubTodasEtapas) unsubTodasEtapas();
    unsubTodasEtapas = escutarTodasEtapas(obras, todas => {
      window._todasEtapas = todas;
      renderExecucao();
      renderAprovacao();
      updateBadge();
    });
  });
  escutarPrecos(p => { db_precos = p; renderPrecos(); });
  escutarRepasses(r => { db_repasses = r; renderRepasse(); });
  escutarParceiros(p => { db_parceiros = p; renderParceiros(); });
  escutarClientes(c => { db_clientes = c; renderClientes(); popularSelectClientes(); });
  escutarAdmins(a => { db_admins = a; renderAdmins(); });
}

// ---------- HELPERS GERAIS ----------
function toast(m) { const t = document.getElementById('toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2400); }
function fmtVal(el) { let v = el.value.replace(/\D/g, ''); if (!v) { el.value = ''; return; } v = (parseInt(v) / 100).toFixed(2); el.value = v.replace('.', ','); }
window.fmtVal = fmtVal;
window.showModal = id => document.getElementById(id).classList.add('show');
window.closeModal = id => document.getElementById(id).classList.remove('show');
window.bgClose = (e, id) => { if (e.target === document.getElementById(id)) window.closeModal(id); };

function fotosHTML(antes, depois, extras) {
  let html = '';
  if (antes || depois) {
    const item = (src, label) => src
      ? `<div><div class="foto-wrap" onclick="openLightbox('${src}','${label}')"><img src="${src}" alt="${label}"></div><div class="foto-lbl">${label}</div></div>`
      : `<div><div class="foto-sem">Sem foto</div><div class="foto-lbl">${label}</div></div>`;
    html += `<div class="fotos-grid">${item(antes, 'Antes')}${item(depois, 'Depois')}</div>`;
  }
  if (extras && extras.length) {
    html += `<div class="fotos-grid" style="margin-top:6px">` + extras.map(f =>
      `<div><div class="foto-wrap" onclick="openLightbox('${f.url}','${f.legenda || 'Foto extra'}')"><img src="${f.url}" alt=""></div><div class="foto-lbl">${f.legenda || 'Execução'}</div></div>`
    ).join('') + `</div>`;
  }
  return html;
}
window.openLightbox = (src, label) => {
  document.getElementById('lightbox-img').src = src;
  document.getElementById('lightbox-label').textContent = label;
  document.getElementById('lightbox').classList.add('show');
  document.body.style.overflow = 'hidden';
};
window.closeLightbox = () => { document.getElementById('lightbox').classList.remove('show'); document.body.style.overflow = ''; };

function prevFoto(input, key) {
  const file = input.files[0]; if (!file) return;
  fileParaBase64(file).then(dataUrl => {
    if (key === 'et-antes') { etFotos.antes = dataUrl; setPrev('et-prev-antes', 'et-icon-antes', dataUrl); }
    if (key === 'conc-depois') { concFoto = dataUrl; setPrev('conc-prev-depois', 'conc-icon-depois', dataUrl); }
    if (key === 'enc-comprovante') { encFoto = dataUrl; setPrev('enc-prev-comprovante', 'enc-icon-comprovante', dataUrl); }
    if (key === 'extra-foto') { extraFoto = dataUrl; setPrev('extra-prev-foto', 'extra-icon-foto', dataUrl); }
  });
}
window.prevFoto = prevFoto;
function setPrev(imgId, iconId, src) {
  document.getElementById(imgId).src = src;
  document.getElementById(imgId).style.display = 'block';
  document.getElementById(iconId).style.display = 'none';
}

function popularSelectTipos(selectId) {
  const sel = document.getElementById(selectId);
  sel.innerHTML = `<option value="">Selecione...</option>`;
  db_precos.forEach(p => { const o = document.createElement('option'); o.value = p.nome; o.textContent = p.nome; sel.appendChild(o); });
  const outros = document.createElement('option'); outros.value = 'Outros'; outros.textContent = 'Outros'; sel.appendChild(outros);
}

function popularSelectParceiros(selectId) {
  const sel = document.getElementById(selectId);
  sel.innerHTML = `<option value="">Selecione...</option>`;
  db_parceiros.forEach(p => { const o = document.createElement('option'); o.value = p.id; o.textContent = p.nome; sel.appendChild(o); });
}

function popularSelectClientes() {
  const sel = document.getElementById('obra-cliente');
  if (!sel) return;
  const atual = sel.value;
  sel.innerHTML = `<option value="">Sem cliente vinculado</option>`;
  db_clientes.filter(c => c.status === 'aprovado').forEach(c => {
    const o = document.createElement('option'); o.value = c.id; o.textContent = c.nome; sel.appendChild(o);
  });
  sel.value = atual;
}

// ---------- NAVEGAÇÃO ----------
const TITULOS = { obras: 'Painel Admin', execucao: 'Em execução', aprovacao: 'Aprovação', parceiros: 'Parceiros', mais: 'Mais opções', precos: 'Tabela de preços', repasse: 'Tabela de repasse', clientes: 'Clientes', admins: 'Administradores' };

window.goPage = function (p) {
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + p).classList.add('active');
  const navEl = document.getElementById('nav-' + p);
  if (navEl) navEl.classList.add('active');
  if (TITULOS[p]) document.getElementById('topbar-content').innerHTML = `<h1>${TITULOS[p]}</h1>`;
  updateBadge();
};

function updateBadge() {
  const todas = window._todasEtapas || [];
  const n = todas.filter(e => e.status === 'concluido' && e.aprovacao === 'pendente').length;
  document.getElementById('dot-aprov').classList.toggle('show', n > 0);
}

// ---------- OBRAS ----------
function renderObras() {
  const and = db_obras.filter(o => o.status === 'andamento').length;
  const conc = db_obras.filter(o => o.status === 'concluida').length;
  document.getElementById('s-total').textContent = db_obras.length;
  document.getElementById('s-and').textContent = and;
  document.getElementById('s-conc').textContent = conc;
  const el = document.getElementById('lista-obras');
  if (!db_obras.length) { el.innerHTML = `<div class="empty"><i class="ti ti-building-off"></i><p>Nenhuma obra cadastrada.<br>Toque em "Nova obra" para começar.</p></div>`; return; }
  el.innerHTML = db_obras.map(o => {
    const cliente = db_clientes.find(c => c.id === o.clienteId);
    const atrasada = o.status === 'andamento' && o.fim && o.fim < hoje();
    return `<div class="list-card" onclick="abrirObra('${o.id}')">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
        <div style="flex:1;min-width:0">
          <div style="font-size:16px;font-weight:600">${o.nome}</div>
          ${o.local ? `<div style="font-size:12px;color:var(--text-muted)">${o.local}</div>` : ''}
          ${cliente ? `<div style="font-size:11px;color:var(--text-accent);margin-top:2px"><i class="ti ti-user"></i> ${cliente.nome}</div>` : ''}
        </div>
        <span class="badge ${o.status === 'andamento' ? 'badge-and' : 'badge-done'}">${o.status === 'andamento' ? 'Em andamento' : 'Concluída'}</span>
      </div>
      ${atrasada ? `<div class="alert-box alert-danger"><i class="ti ti-alert-triangle"></i>Prazo vencido</div>` : ''}
    </div>`;
  }).join('');
}

window.salvarObra = async function () {
  const nome = document.getElementById('obra-nome').value.trim();
  const clienteId = document.getElementById('obra-cliente').value;
  const local = document.getElementById('obra-local').value.trim();
  const inicio = document.getElementById('obra-inicio').value;
  const fim = document.getElementById('obra-fim').value;
  const desc = document.getElementById('obra-desc').value.trim();
  const mostrarPedreiro = document.getElementById('obra-mostrar-pedreiro').checked;
  if (!nome) { toast('Informe o nome da obra'); return; }
  try {
    await criarObra({ nome, clienteId: clienteId || null, local, inicio, fim, desc, mostrarPedreiro });
    window.closeModal('modal-nova-obra');
    ['obra-nome', 'obra-local', 'obra-inicio', 'obra-fim', 'obra-desc'].forEach(i => document.getElementById(i).value = '');
    document.getElementById('obra-cliente').value = '';
    document.getElementById('obra-mostrar-pedreiro').checked = true;
    toast('Obra criada');
  } catch (e) { toast('Erro ao criar obra'); console.error(e); }
};

window.abrirObra = function (id) {
  obraAtiva = db_obras.find(o => o.id === id);
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('page-obra-detalhe').classList.add('active');
  document.getElementById('topbar-content').innerHTML = `<h1 style="font-size:15px">${obraAtiva.nome}</h1>`;
  if (unsubEtapasAtivas) unsubEtapasAtivas();
  unsubEtapasAtivas = escutarEtapas(id, etapas => { obraAtiva._etapas = etapas; renderDetalheObra(); });
  if (unsubEncargos) unsubEncargos();
  unsubEncargos = escutarEncargos(id, encargos => { obraAtiva._encargos = encargos; renderEncargos(); });
};

function renderDetalheObra() {
  if (!obraAtiva) return;
  const o = obraAtiva;
  const etapas = o._etapas || [];
  const done = etapas.filter(e => e.status === 'concluido').length;
  const pct = etapas.length ? Math.round(done / etapas.length * 100) : 0;
  const gastoEtapas = etapas.reduce((s, e) => s + parseFloat((e.val || '0').replace(',', '.')), 0);
  const gastoEncargos = (o._encargos || []).reduce((s, e) => s + parseFloat((e.valor || '0').replace(',', '.')), 0);
  const gasto = gastoEtapas + gastoEncargos;
  const atrasada = o.status === 'andamento' && o.fim && o.fim < hoje();
  const cliente = db_clientes.find(c => c.id === o.clienteId);
  document.getElementById('obra-detalhe-header').innerHTML = `
    <div class="card">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:10px">
        <span class="badge ${o.status === 'andamento' ? 'badge-and' : 'badge-done'}">${o.status === 'andamento' ? 'Em andamento' : 'Concluída'}</span>
        ${o.status === 'andamento' ? `<button class="btn-sm btn-danger" onclick="concluirObra('${o.id}')" style="font-size:11px">Concluir obra</button>` : ''}
      </div>
      ${cliente ? `<div style="font-size:12px;color:var(--text-accent);margin-bottom:6px"><i class="ti ti-user"></i> Cliente: ${cliente.nome}</div>` : `<div style="font-size:12px;color:var(--text-muted);margin-bottom:6px">Sem cliente vinculado</div>`}
      ${atrasada ? `<div class="alert-box alert-danger"><i class="ti ti-alert-triangle"></i>Prazo vencido — previsão: ${o.fim}</div>` : ''}
      <div class="g3" style="margin-top:8px">
        <div class="stat"><span class="stat-val">${etapas.length}</span><span class="stat-lbl">Etapas</span></div>
        <div class="stat"><span class="stat-val">${pct}%</span><span class="stat-lbl">Progresso</span></div>
        <div class="stat"><span class="stat-val" style="font-size:14px">R$ ${gasto.toFixed(2).replace('.', ',')}</span><span class="stat-lbl">Total</span></div>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
      ${o.status === 'andamento' ? `<div class="g2" style="margin-top:12px">
        <button class="btn-sm btn-success" onclick="abrirNovaEtapa()" style="justify-content:center;padding:10px"><i class="ti ti-plus"></i> Etapa</button>
        <button class="btn-sm" onclick="abrirEncargo()" style="justify-content:center;padding:10px"><i class="ti ti-receipt"></i> Encargo</button>
      </div>` : ''}
    </div>`;
  renderEtapas();
}

window.concluirObra = async function (id) {
  if (!confirm('Confirmar conclusão da obra?')) return;
  await atualizarObra(id, { status: 'concluida', dataConc: hoje() });
  toast('Obra concluída');
};

// ---------- ENCARGOS ----------
function renderEncargos() {
  const encargos = obraAtiva._encargos || [];
  const el = document.getElementById('obra-encargos-area');
  if (!encargos.length) { el.innerHTML = ''; return; }
  el.innerHTML = `<div class="card"><div style="font-size:14px;font-weight:600;margin-bottom:8px">Encargos extras (${encargos.length})</div>` +
    encargos.map(e => `<div class="row-item">
      <div class="row-info">
        <div class="row-title">${e.descricao}</div>
        <div class="row-meta">R$ ${e.valor}</div>
      </div>
      <div class="row-actions">
        ${e.comprovante ? `<button class="btn-sm" onclick="openLightbox('${e.comprovante}','Comprovante')"><i class="ti ti-receipt"></i></button>` : ''}
        <button class="btn-sm btn-danger" onclick="removerEncargo('${e.id}')"><i class="ti ti-trash"></i></button>
      </div>
    </div>`).join('') + `</div>`;
}

window.abrirEncargo = function () {
  encFoto = null;
  document.getElementById('enc-desc').value = '';
  document.getElementById('enc-valor').value = '';
  document.getElementById('enc-prev-comprovante').style.display = 'none';
  document.getElementById('enc-icon-comprovante').style.display = 'flex';
  window.showModal('modal-encargo');
};

window.salvarEncargo = async function () {
  const descricao = document.getElementById('enc-desc').value.trim();
  const valor = document.getElementById('enc-valor').value;
  if (!descricao) { toast('Informe a descrição'); return; }
  if (!valor) { toast('Informe o valor'); return; }
  const btn = document.getElementById('btn-salvar-encargo');
  btn.disabled = true; btn.textContent = 'Salvando...';
  try {
    let comprovanteUrl = null;
    if (encFoto) comprovanteUrl = await uploadFoto(encFoto, `obras/${obraAtiva.id}/encargos/${Date.now()}.jpg`);
    await criarEncargo(obraAtiva.id, { descricao, valor, comprovante: comprovanteUrl });
    window.closeModal('modal-encargo');
    toast('Encargo adicionado');
  } catch (e) { toast('Erro ao salvar'); console.error(e); }
  btn.disabled = false; btn.textContent = 'Adicionar encargo';
};

window.removerEncargo = async function (id) {
  if (!confirm('Remover este encargo?')) return;
  await excluirEncargo(obraAtiva.id, id);
  toast('Encargo removido');
};

// ---------- ETAPAS ----------
window.onTipoChange = function () {
  const tipo = document.getElementById('et-tipo').value;
  const preco = db_precos.find(p => p.nome === tipo);
  const boxMetros = document.getElementById('box-metros');
  const boxToggle = document.getElementById('box-toggle-custom');
  const boxSugerido = document.getElementById('preco-sugerido-box');
  document.getElementById('toggle-custom').checked = false;
  document.getElementById('valor-custom-box').classList.remove('show');
  if (preco) {
    document.getElementById('preco-sugerido-info').textContent = `Preço de referência: R$ ${preco.val}/m²`;
    document.getElementById('preco-sugerido-calc').textContent = 'Informe a quantidade em m² para calcular.';
    boxSugerido.classList.add('show');
    boxMetros.style.display = 'grid';
    boxToggle.style.display = 'flex';
    document.getElementById('et-metros').value = '';
    document.getElementById('et-valor-calc').value = '';
    const metrosEl = document.getElementById('et-metros');
    metrosEl.oninput = () => calcularValor();
    metrosEl.readOnly = false;
  } else {
    boxSugerido.classList.remove('show');
    boxMetros.style.display = 'none';
    boxToggle.style.display = 'none';
  }
};

function calcularValor() {
  if (document.getElementById('toggle-custom').checked) return;
  const tipo = document.getElementById('et-tipo').value;
  const preco = db_precos.find(p => p.nome === tipo);
  if (!preco) return;
  const metros = parseFloat(document.getElementById('et-metros').value) || 0;
  const precoPorM2 = parseFloat(preco.val.replace(',', '.')) || 0;
  const total = metros * precoPorM2;
  document.getElementById('et-valor-calc').value = total > 0 ? total.toFixed(2).replace('.', ',') : '';
  document.getElementById('preco-sugerido-calc').textContent = metros > 0 ? `${metros} m² × R$ ${preco.val} = R$ ${total.toFixed(2).replace('.', ',')}` : 'Informe a quantidade em m² para calcular.';
}
window.calcularValor = calcularValor;

window.recalcularComCustom = function () {
  const novoPreco = parseFloat((document.getElementById('et-valor-custom').value || '0').replace(',', '.')) || 0;
  const metros = parseFloat(document.getElementById('et-metros').value) || 0;
  const total = novoPreco * metros;
  document.getElementById('et-valor-calc').value = total > 0 ? total.toFixed(2).replace('.', ',') : '';
  if (metros > 0 && novoPreco > 0) {
    document.getElementById('preco-sugerido-calc').textContent = `${metros} m² × R$ ${document.getElementById('et-valor-custom').value} = R$ ${total.toFixed(2).replace('.', ',')} (valor personalizado)`;
  }
};

window.toggleCustomVal = function () {
  const on = document.getElementById('toggle-custom').checked;
  document.getElementById('valor-custom-box').classList.toggle('show', on);
  const metrosEl = document.getElementById('et-metros');
  if (on) {
    metrosEl.oninput = null;
    metrosEl.readOnly = true;
    metrosEl.style.background = 'var(--surface-1)';
    metrosEl.style.color = 'var(--text-muted)';
    document.getElementById('et-valor-custom').value = '';
    document.getElementById('et-valor-calc').value = '';
  } else {
    metrosEl.readOnly = false;
    metrosEl.style.background = '';
    metrosEl.style.color = '';
    metrosEl.oninput = () => calcularValor();
    document.getElementById('et-valor-custom').value = '';
    calcularValor();
  }
};

window.abrirNovaEtapa = function () {
  etFotos = {};
  document.getElementById('et-inicio').value = hoje();
  document.getElementById('et-prev-antes').style.display = 'none';
  document.getElementById('et-icon-antes').style.display = 'flex';
  ['et-prazo', 'et-obs', 'et-valor-custom', 'et-motivo', 'et-metros', 'et-valor-calc'].forEach(i => { const el = document.getElementById(i); if (el) el.value = ''; });
  document.getElementById('toggle-custom').checked = false;
  document.getElementById('valor-custom-box').classList.remove('show');
  document.getElementById('preco-sugerido-box').classList.remove('show');
  document.getElementById('box-metros').style.display = 'none';
  document.getElementById('box-toggle-custom').style.display = 'none';
  popularSelectTipos('et-tipo');
  popularSelectParceiros('et-parceiro');
  window.showModal('modal-nova-etapa');
};

window.salvarEtapa = async function () {
  const tipo = document.getElementById('et-tipo').value;
  const parceiroId = document.getElementById('et-parceiro').value;
  const inicio = document.getElementById('et-inicio').value;
  const prazo = document.getElementById('et-prazo').value;
  const obs = document.getElementById('et-obs').value.trim();
  if (!tipo) { toast('Selecione o tipo de serviço'); return; }
  if (!parceiroId) { toast('Selecione o parceiro responsável'); return; }
  const parceiro = db_parceiros.find(p => p.id === parceiroId);

  const isCustom = document.getElementById('toggle-custom').checked;
  const preco = db_precos.find(p => p.nome === tipo);
  let val, motivo = '', metros = null, precoPorM2 = null;

  if (preco && !isCustom) {
    val = document.getElementById('et-valor-calc').value;
    metros = document.getElementById('et-metros').value;
    precoPorM2 = preco.val;
    if (!val) { toast('Informe a quantidade em m² para calcular'); return; }
  } else if (preco && isCustom) {
    val = document.getElementById('et-valor-calc').value;
    metros = document.getElementById('et-metros').value;
    precoPorM2 = document.getElementById('et-valor-custom').value;
    motivo = document.getElementById('et-motivo').value.trim();
    if (!val) { toast('Informe o novo preço por m²'); return; }
  } else {
    val = ''; metros = null;
  }

  const btn = document.getElementById('btn-salvar-etapa');
  btn.disabled = true; btn.textContent = 'Salvando...';
  try {
    let fotoAntesUrl = null;
    if (etFotos.antes) fotoAntesUrl = await uploadFoto(etFotos.antes, `obras/${obraAtiva.id}/etapas/${Date.now()}_antes.jpg`);
    await criarEtapa(obraAtiva.id, {
      tipo, parceiroId, parceiroNome: parceiro.nome, val, metros: metros || null, precoPorM2: precoPorM2 || null,
      motivo, inicio, prazo, obs, fotoAntes: fotoAntesUrl, fotosExtras: []
    });
    window.closeModal('modal-nova-etapa');
    toast('Etapa adicionada');
  } catch (e) { toast('Erro ao salvar etapa'); console.error(e); }
  btn.disabled = false; btn.textContent = 'Adicionar etapa';
};

function renderEtapas() {
  const etapas = obraAtiva._etapas || [];
  const el = document.getElementById('obra-etapas');
  if (!etapas.length) { el.innerHTML = `<div class="empty"><i class="ti ti-clipboard"></i><p>Nenhuma etapa ainda.<br>Adicione a primeira etapa acima.</p></div>`; return; }
  const hoje_ = hoje();
  el.innerHTML = `<div class="card"><div style="font-size:14px;font-weight:600;margin-bottom:4px">Etapas (${etapas.length})</div>` +
    etapas.map(e => {
      const atrasada = e.status === 'execucao' && e.prazo && e.prazo < hoje_;
      const dr = e.prazo ? diasDiff(hoje_, e.prazo) : null;
      let tempoReal = '';
      if (e.status === 'concluido' && e.inicio && e.dataConc) { const d = diasDiff(e.inicio, e.dataConc); tempoReal = ` · ${d} dia${d !== 1 ? 's' : ''} real`; }
      const valDisplay = e.val ? ` · R$ ${e.val}` : '';
      const pagamentoBadge = e.status === 'concluido' && e.aprovacao === 'aprovado' ? `<span class="badge ${e.pagamento === 'pago' ? 'badge-pago' : 'badge-apagar'}" style="margin-left:4px">${e.pagamento === 'pago' ? 'Pago' : 'A pagar'}</span>` : '';
      return `<div class="row-item">
        <div class="row-info">
          <div class="row-title">${e.tipo}</div>
          <div class="row-meta">${e.parceiroNome}${valDisplay}${e.metros ? ` · ${e.metros}m²` : ''}${tempoReal}</div>
          ${e.motivo ? `<div style="font-size:10px;color:var(--text-warning)">Valor personalizado: ${e.motivo}</div>` : ''}
          ${atrasada ? `<div style="font-size:10px;color:var(--text-danger)">Atrasada</div>` : ''}
          ${!atrasada && dr !== null && e.status === 'execucao' ? `<div style="font-size:10px;color:var(--text-muted)">${dr >= 0 ? dr + 'd restante(s)' : 'no prazo'}</div>` : ''}
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end">
          <span class="badge ${e.status === 'execucao' ? 'badge-exec' : e.aprovacao === 'aprovado' ? 'badge-aprov' : e.aprovacao === 'rejeitado' ? 'badge-rej' : 'badge-pend'}">${e.status === 'execucao' ? 'Execução' : e.aprovacao === 'aprovado' ? 'Aprovado' : e.aprovacao === 'rejeitado' ? 'Rejeitado' : 'Pendente'}</span>
          ${pagamentoBadge}
          ${e.status === 'execucao' ? `<button class="btn-sm" onclick="abrirFotoExtra('${e.id}')" style="font-size:11px;padding:5px 9px"><i class="ti ti-camera-plus"></i></button>` : ''}
          ${e.status === 'execucao' ? `<button class="btn-sm btn-success" onclick="abrirConcluir('${e.id}')" style="font-size:11px;padding:5px 9px">Concluir</button>` : ''}
        </div>
      </div>`;
    }).join('') + '</div>';
}

let etapaFotoExtraId = null;
window.abrirFotoExtra = function (etId) {
  etapaFotoExtraId = etId;
  extraFoto = null;
  document.getElementById('extra-legenda').value = '';
  document.getElementById('extra-prev-foto').style.display = 'none';
  document.getElementById('extra-icon-foto').style.display = 'flex';
  window.showModal('modal-foto-extra');
};

window.salvarFotoExtra = async function () {
  if (!extraFoto) { toast('Selecione uma foto'); return; }
  const btn = document.getElementById('btn-salvar-foto-extra');
  btn.disabled = true; btn.textContent = 'Enviando...';
  try {
    const url = await uploadFoto(extraFoto, `obras/${obraAtiva.id}/etapas/extras/${Date.now()}.jpg`);
    const legenda = document.getElementById('extra-legenda').value.trim();
    const etapa = (obraAtiva._etapas || []).find(e => e.id === etapaFotoExtraId);
    const fotosExtras = [...(etapa.fotosExtras || []), { url, legenda }];
    await atualizarEtapa(obraAtiva.id, etapaFotoExtraId, { fotosExtras });
    window.closeModal('modal-foto-extra');
    toast('Foto adicionada');
  } catch (e) { toast('Erro ao enviar foto'); console.error(e); }
  btn.disabled = false; btn.textContent = 'Adicionar foto';
};

window.abrirConcluir = function (etId) {
  etapaConclId = etId;
  concFoto = null;
  document.getElementById('conc-data').value = hoje();
  document.getElementById('conc-obs').value = '';
  document.getElementById('conc-prev-depois').style.display = 'none';
  document.getElementById('conc-icon-depois').style.display = 'flex';
  window.showModal('modal-concluir');
};

window.confirmarConclusao = async function () {
  const dataConc = document.getElementById('conc-data').value;
  const obsConc = document.getElementById('conc-obs').value.trim();
  if (!dataConc) { toast('Informe a data de conclusão'); return; }
  const btn = document.getElementById('btn-concluir-etapa');
  btn.disabled = true; btn.textContent = 'Salvando...';
  try {
    let fotoDepoisUrl = null;
    if (concFoto) fotoDepoisUrl = await uploadFoto(concFoto, `obras/${obraAtiva.id}/etapas/${Date.now()}_depois.jpg`);
    const etapa = (obraAtiva._etapas || []).find(e => e.id === etapaConclId);
    const tempoReal = etapa.inicio ? diasDiff(etapa.inicio, dataConc) : null;
    await atualizarEtapa(obraAtiva.id, etapaConclId, { status: 'concluido', dataConc, obsConc, fotoDepois: fotoDepoisUrl, aprovacao: 'pendente', tempoReal });
    window.closeModal('modal-concluir');
    toast('Etapa concluída');
  } catch (e) { toast('Erro ao concluir'); console.error(e); }
  btn.disabled = false; btn.textContent = 'Concluir etapa';
};

// ---------- EM EXECUÇÃO (global) ----------
function renderExecucao() {
  const el = document.getElementById('lista-execucao');
  const rows = (window._todasEtapas || []).filter(e => e.status === 'execucao');
  if (!rows.length) { el.innerHTML = `<div class="empty"><i class="ti ti-tools"></i><p>Nenhum serviço em execução.</p></div>`; return; }
  const hoje_ = hoje();
  el.innerHTML = rows.map(e => {
    const atrasada = e.prazo && e.prazo < hoje_;
    const dr = e.prazo ? diasDiff(hoje_, e.prazo) : null;
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div><div style="font-size:15px;font-weight:600">${e.tipo}</div><div style="font-size:12px;color:var(--text-muted)">${e.obraNome}</div></div>
        ${atrasada ? '<span class="badge badge-rej"><i class="ti ti-alert-triangle"></i> Atrasado</span>' : '<span class="badge badge-exec">Em execução</span>'}
      </div>
      <div class="divider"></div>
      <div class="g2">
        <div><div style="font-size:11px;color:var(--text-muted)">Parceiro</div><div style="font-size:13px;font-weight:500">${e.parceiroNome}</div></div>
        <div><div style="font-size:11px;color:var(--text-muted)">Valor</div><div style="font-size:13px;font-weight:600;color:var(--text-success)">${e.val ? 'R$ ' + e.val : '—'}</div></div>
        <div><div style="font-size:11px;color:var(--text-muted)">Início</div><div style="font-size:13px">${e.inicio || '—'}</div></div>
        <div><div style="font-size:11px;color:var(--text-muted)">Prazo</div><div style="font-size:13px${atrasada ? ';color:var(--text-danger)' : ''}">${e.prazo || '—'}${dr !== null && !atrasada ? ` (${dr}d)` : ''}${atrasada ? ' (vencido)' : ''}</div></div>
      </div>
    </div>`;
  }).join('');
}

// ---------- APROVAÇÃO (global) ----------
function renderAprovacao() {
  const el = document.getElementById('lista-aprovacao');
  const rows = (window._todasEtapas || []).filter(e => e.status === 'concluido' && e.aprovacao === 'pendente');
  if (!rows.length) { el.innerHTML = `<div class="empty"><i class="ti ti-circle-check"></i><p>Nenhum serviço aguardando aprovação.</p></div>`; return; }
  el.innerHTML = rows.map(e => `<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div><div style="font-size:15px;font-weight:600">${e.tipo}</div><div style="font-size:12px;color:var(--text-muted)">${e.obraNome}</div></div>
      <span class="badge badge-pend">Pendente</span>
    </div>
    <div class="divider"></div>
    <div class="g2" style="margin-bottom:10px">
      <div><div style="font-size:11px;color:var(--text-muted)">Parceiro</div><div style="font-size:13px;font-weight:500">${e.parceiroNome}</div></div>
      <div><div style="font-size:11px;color:var(--text-muted)">Valor</div><div style="font-size:13px;font-weight:600;color:var(--text-success)">${e.val ? 'R$ ' + e.val : '—'}</div></div>
    </div>
    ${fotosHTML(e.fotoAntes, e.fotoDepois, e.fotosExtras)}
    <p style="font-size:11px;color:var(--text-muted);margin-top:8px">A aprovação final é feita pelo cliente. Aqui você apenas acompanha.</p>
  </div>`).join('');
}

// ---------- PARCEIROS ----------
function renderParceiros() {
  const el = document.getElementById('lista-parceiros');
  if (!db_parceiros.length) { el.innerHTML = `<div class="empty"><i class="ti ti-users-group"></i><p>Nenhum parceiro cadastrado.</p></div>`; return; }
  el.innerHTML = db_parceiros.map(p => `<div class="list-card" onclick="abrirParceiroDetalhe('${p.id}')">
    <div style="display:flex;align-items:center;gap:10px">
      <div class="avatar">${(p.nome || '?').split(' ').map(x => x[0]).slice(0, 2).join('').toUpperCase()}</div>
      <div style="flex:1">
        <div style="font-size:14px;font-weight:600">${p.nome}</div>
        <div style="font-size:12px;color:var(--text-muted)">${p.doc || 'Sem documento'}</div>
      </div>
      <i class="ti ti-chevron-right" style="color:var(--text-muted)"></i>
    </div>
  </div>`).join('');
}

window.abrirNovoParceiro = function () {
  editParceiroId = null;
  document.getElementById('parceiro-modal-title').textContent = 'Novo parceiro';
  document.getElementById('parc-nome').value = '';
  document.getElementById('parc-doc').value = '';
  document.getElementById('parc-tel').value = '';
  window.showModal('modal-novo-parceiro');
};

window.editarParceiro = function (id) {
  const p = db_parceiros.find(x => x.id === id); if (!p) return;
  editParceiroId = id;
  document.getElementById('parceiro-modal-title').textContent = 'Editar parceiro';
  document.getElementById('parc-nome').value = p.nome;
  document.getElementById('parc-doc').value = p.doc || '';
  document.getElementById('parc-tel').value = p.telefone || '';
  window.showModal('modal-novo-parceiro');
};

window.salvarParceiro = async function () {
  const nome = document.getElementById('parc-nome').value.trim();
  const docCpfCnpj = document.getElementById('parc-doc').value.trim();
  const telefone = document.getElementById('parc-tel').value.trim();
  if (!nome) { toast('Informe o nome'); return; }
  const btn = document.getElementById('btn-salvar-parceiro');
  btn.disabled = true;
  try {
    if (editParceiroId) await atualizarParceiro(editParceiroId, { nome, doc: docCpfCnpj, telefone });
    else await criarParceiro({ nome, doc: docCpfCnpj, telefone });
    window.closeModal('modal-novo-parceiro');
    toast('Parceiro salvo');
  } catch (e) { toast('Erro ao salvar'); console.error(e); }
  btn.disabled = false;
};

window.abrirParceiroDetalhe = function (id) {
  parceiroDetalheId = id;
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('page-parceiro-detalhe').classList.add('active');
  renderParceiroDetalhe();
};

function renderParceiroDetalhe() {
  const p = db_parceiros.find(x => x.id === parceiroDetalheId); if (!p) return;
  document.getElementById('topbar-content').innerHTML = `<h1 style="font-size:15px">${p.nome}</h1>`;
  // Busca histórico de etapas desse parceiro em todas as obras já carregadas
  const todas = window._todasEtapas || [];
  const historico = todas.filter(e => e.parceiroId === p.id);
  const totalGanho = historico.filter(e => e.status === 'concluido').reduce((s, e) => s + parseFloat((e.val || '0').replace(',', '.')), 0);
  const el = document.getElementById('parceiro-detalhe-content');
  el.innerHTML = `
    <div class="card">
      <div class="g2 mb">
        <div><label>CPF/CNPJ</label><div style="font-size:14px">${p.doc || '—'}</div></div>
        <div><label>Telefone</label><div style="font-size:14px">${p.telefone || '—'}</div></div>
      </div>
      <div class="g2">
        <button class="btn-sm" onclick="editarParceiro('${p.id}')"><i class="ti ti-edit"></i> Editar</button>
        <button class="btn-sm btn-danger" onclick="removerParceiro('${p.id}')"><i class="ti ti-trash"></i> Excluir</button>
      </div>
    </div>
    <div class="stat-row">
      <div class="stat"><span class="stat-val">${historico.length}</span><span class="stat-lbl">Serviços</span></div>
      <div class="stat" style="grid-column:span 2"><span class="stat-val" style="font-size:18px">R$ ${totalGanho.toFixed(2).replace('.', ',')}</span><span class="stat-lbl">Total ganho</span></div>
    </div>
    <div class="sec-title">Histórico de serviços</div>
    ${!historico.length ? `<div class="empty"><i class="ti ti-clipboard-off"></i><p>Nenhum serviço registrado ainda.</p></div>` :
      `<div class="card">` + historico.map(e => `<div class="row-item">
        <div class="row-info">
          <div class="row-title">${e.tipo} <span style="color:var(--text-muted);font-weight:400">— ${e.obraNome}</span></div>
          <div class="row-meta">${e.val ? 'R$ ' + e.val : '—'} ${e.metros ? '· ' + e.metros + 'm²' : ''}</div>
        </div>
        <span class="badge ${e.status === 'execucao' ? 'badge-exec' : 'badge-done'}">${e.status === 'execucao' ? 'Em execução' : 'Concluído'}</span>
      </div>`).join('') + `</div>`}
  `;
}

window.removerParceiro = async function (id) {
  if (!confirm('Excluir este parceiro? O histórico de serviços já registrados permanece.')) return;
  await excluirParceiro(id);
  window.goPage('parceiros');
  toast('Parceiro excluído');
};

// ---------- TABELA DE PREÇOS (cliente) ----------
function renderPrecos() {
  const el = document.getElementById('lista-precos');
  if (!db_precos.length) { el.innerHTML = `<div class="empty"><i class="ti ti-receipt-off"></i><p>Nenhum preço cadastrado.</p></div>`; return; }
  el.innerHTML = db_precos.map(p => `<div class="price-row">
    <span class="price-name">${p.nome}</span>
    <span class="price-val">R$ ${p.val}/m²</span>
    <div class="row-actions">
      <button class="btn-sm" onclick="editarPreco('${p.id}')"><i class="ti ti-edit"></i></button>
      <button class="btn-sm btn-danger" onclick="removerPreco('${p.id}')"><i class="ti ti-trash"></i></button>
    </div>
  </div>`).join('');
}
window.showModalPreco = function () { editPrecoId = null; document.getElementById('preco-modal-title').textContent = 'Novo serviço'; document.getElementById('preco-nome').value = ''; document.getElementById('preco-val').value = ''; window.showModal('modal-preco'); };
window.editarPreco = function (id) { const p = db_precos.find(x => x.id === id); if (!p) return; editPrecoId = id; document.getElementById('preco-modal-title').textContent = 'Editar serviço'; document.getElementById('preco-nome').value = p.nome; document.getElementById('preco-val').value = p.val; window.showModal('modal-preco'); };
window.salvarPreco = async function () {
  const nome = document.getElementById('preco-nome').value.trim();
  const val = document.getElementById('preco-val').value;
  if (!nome) { toast('Informe o nome'); return; }
  if (!val) { toast('Informe o preço'); return; }
  const btn = document.getElementById('btn-salvar-preco'); btn.disabled = true;
  try {
    if (editPrecoId) await atualizarPreco(editPrecoId, nome, val);
    else await criarPreco(nome, val);
    window.closeModal('modal-preco'); toast('Salvo com sucesso');
  } catch (e) { toast('Erro ao salvar'); console.error(e); }
  btn.disabled = false;
};
window.removerPreco = async function (id) { if (!confirm('Excluir este serviço da tabela?')) return; await excluirPreco(id); toast('Excluído'); };

// ---------- TABELA DE REPASSE (interna) ----------
function renderRepasse() {
  const el = document.getElementById('lista-repasse');
  if (!db_repasses.length) { el.innerHTML = `<div class="empty"><i class="ti ti-coin-off"></i><p>Nenhum repasse cadastrado.</p></div>`; return; }
  el.innerHTML = db_repasses.map(p => `<div class="price-row">
    <span class="price-name">${p.nome}</span>
    <span class="price-val">R$ ${p.val}/m²</span>
    <div class="row-actions">
      <button class="btn-sm" onclick="editarRepasse('${p.id}')"><i class="ti ti-edit"></i></button>
      <button class="btn-sm btn-danger" onclick="removerRepasse('${p.id}')"><i class="ti ti-trash"></i></button>
    </div>
  </div>`).join('');
}
window.showModalRepasse = function () { editRepasseId = null; document.getElementById('repasse-modal-title').textContent = 'Novo repasse'; document.getElementById('repasse-nome').value = ''; document.getElementById('repasse-val').value = ''; window.showModal('modal-repasse'); };
window.editarRepasse = function (id) { const p = db_repasses.find(x => x.id === id); if (!p) return; editRepasseId = id; document.getElementById('repasse-modal-title').textContent = 'Editar repasse'; document.getElementById('repasse-nome').value = p.nome; document.getElementById('repasse-val').value = p.val; window.showModal('modal-repasse'); };
window.salvarRepasse = async function () {
  const nome = document.getElementById('repasse-nome').value.trim();
  const val = document.getElementById('repasse-val').value;
  if (!nome) { toast('Informe o nome'); return; }
  if (!val) { toast('Informe o custo'); return; }
  const btn = document.getElementById('btn-salvar-repasse'); btn.disabled = true;
  try {
    if (editRepasseId) await atualizarRepasse(editRepasseId, nome, val);
    else await criarRepasse(nome, val);
    window.closeModal('modal-repasse'); toast('Salvo com sucesso');
  } catch (e) { toast('Erro ao salvar'); console.error(e); }
  btn.disabled = false;
};
window.removerRepasse = async function (id) { if (!confirm('Excluir este repasse?')) return; await excluirRepasse(id); toast('Excluído'); };

// ---------- CLIENTES ----------
function renderClientes() {
  const el = document.getElementById('lista-clientes');
  if (!db_clientes.length) { el.innerHTML = `<div class="empty"><i class="ti ti-users"></i><p>Nenhum cliente cadastrado ainda.</p></div>`; return; }
  el.innerHTML = db_clientes.map(c => {
    const statusBadge = c.status === 'aprovado' ? `<span class="badge badge-aprov">Aprovado</span>` : c.status === 'rejeitado' ? `<span class="badge badge-rej">Rejeitado</span>` : `<span class="badge badge-pend">Pendente</span>`;
    return `<div class="client-card">
      <div class="avatar">${(c.nome || '?').split(' ').map(x => x[0]).slice(0, 2).join('').toUpperCase()}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:600">${c.nome}</div>
        <div style="font-size:12px;color:var(--text-muted)">${c.email}</div>
      </div>
      ${statusBadge}
      ${c.status === 'pendente' ? `<div class="row-actions" style="margin-left:6px">
        <button class="btn-sm btn-success" onclick="aprovarClienteAcao('${c.id}')"><i class="ti ti-check"></i></button>
        <button class="btn-sm btn-danger" onclick="rejeitarClienteAcao('${c.id}')"><i class="ti ti-x"></i></button>
      </div>` : ''}
    </div>`;
  }).join('');
}
window.aprovarClienteAcao = async function (uid) { await aprovarCliente(uid); toast('Cliente aprovado'); };
window.rejeitarClienteAcao = async function (uid) { if (!confirm('Rejeitar este cliente?')) return; await rejeitarCliente(uid); toast('Cliente rejeitado'); };

// ---------- ADMINS ----------
function renderAdmins() {
  const el = document.getElementById('lista-admins');
  if (!db_admins.length) { el.innerHTML = `<div class="empty"><i class="ti ti-shield-off"></i><p>Nenhum admin cadastrado.</p></div>`; return; }
  el.innerHTML = db_admins.map(a => `<div class="client-card">
    <div class="avatar">${(a.nome || '?').split(' ').map(x => x[0]).slice(0, 2).join('').toUpperCase()}</div>
    <div style="flex:1;min-width:0">
      <div style="font-size:14px;font-weight:600">${a.nome}</div>
      <div style="font-size:12px;color:var(--text-muted)">${a.email}</div>
    </div>
  </div>`).join('');
}

window.salvarNovoAdmin = async function () {
  const nome = document.getElementById('adm-nome').value.trim();
  const email = document.getElementById('adm-email').value.trim();
  const senha = document.getElementById('adm-senha').value;
  if (!nome || !email || !senha) { toast('Preencha todos os campos'); return; }
  const btn = document.getElementById('btn-salvar-admin'); btn.disabled = true; btn.textContent = 'Criando...';
  try {
    await cadastrarAdmin(nome, email, senha);
    // cadastrarAdmin troca o usuário logado no client SDK para o novo admin.
    // Por segurança, deslogamos e pedimos para o admin master entrar de novo.
    window.closeModal('modal-novo-admin');
    toast('Administrador criado! Você precisa entrar novamente.');
    setTimeout(async () => { await logout(); window.location.href = '../index.html'; }, 1800);
  } catch (e) {
    toast(mensagemErroFirebase(e));
  }
  btn.disabled = false; btn.textContent = 'Criar administrador';
};
